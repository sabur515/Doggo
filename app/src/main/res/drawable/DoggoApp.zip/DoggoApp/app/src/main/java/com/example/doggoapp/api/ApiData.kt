package com.example.doggoapp.api

data class ApiData (
    val fileSizeBytes: Int,
    val url: String
)